//: ## Error Handling in Swift
//:
//: There are many ways to handle errors in Swift, here they are.

import UIKit

enum WindStrength: ErrorType {
    case Gust
    case Gale
    case Hurricane
}

//: ### Propagate the error from a function to the code that calls the function

class WeatherManager {
    
    // in MPH
    var currentWindSpeed = 34
    
    func isWeatherSafe() throws -> Bool {
        
        if currentWindSpeed >= 25 && currentWindSpeed <= 38 {
            throw WindStrength.Gust
        } else if currentWindSpeed >= 39 && currentWindSpeed <= 72 {
            throw WindStrength.Gale
        } else if currentWindSpeed >= 73 {
            throw WindStrength.Hurricane
        }
        
        // good for cleanup, such as closing a file that was opened
        defer {
            print("do clean up task")
        }
        
        return true
        
    }
    
}

//: ### Handle the error using a do-catch statement

var weatherManager = WeatherManager()
var isSafe: Bool? {
    didSet {
        print("Must be safe")
    }
}

do {
    isSafe = try weatherManager.isWeatherSafe()
} catch WindStrength.Gust {
    print("You should go somewhere safe")
} catch WindStrength.Gale {
    print("Strong winds, to say the least")
} catch WindStrength.Hurricane {
    print("Hurricane winds, best of luck")
} catch {
    print(error)
}


/*:

----

*/

// Another example: Convert Swift dictionary to json string
let completed = [ "0" : "Rain", "1" : "Sun", "2" : "Wind", "3" : "Snow"]
var stringArray: String?
do {
    let data = try NSJSONSerialization.dataWithJSONObject(completed, options: NSJSONWritingOptions.PrettyPrinted)
    stringArray = String(data: data, encoding: NSUTF8StringEncoding)
} catch {
    print("Could not execute array conversion to Json string")
}

//: ### Handle the error as an optional value
//:
//: If you don't care about the error type, use try?
//: More concise than the do-catch syntax

weatherManager.currentWindSpeed = 50
// If any error, value is nil
if let _ = try? weatherManager.isWeatherSafe() {
    print("Weather is fine, wind is calm")
} else {
    print("error")
}

// Bonus: ?? operator takes the value that is not nil, if possible
var myValue = try? weatherManager.isWeatherSafe()
let safeWeather = myValue ?? false

/*:
    There is a force try, but I think it should be rarely used because you get a runtime error if it fails

    // Apple's example
    let photo = try! loadImage("./Resources/John Appleseed.jpg")
*/

//: ### Assert that an error will not occur
/*: Setup and use a link reference.
[Swift Asserts]: http://blog.krzyzanowskim.com/2015/03/09/swift-asserts-the-missing-manual/ "Swift asserts"
    
Example from [Swift Asserts].
*/

func transformString(string: String?) -> String {
    assert(string != nil, "Invalid parameter")
    return string! + "_transformed"
}

transformString("hi")


//: #### Exceptions do not exsist in Swift language, but they do in Objective-C.
//: ![Image explaining errors/exceptions](http://rypress.com/tutorials/objective-c/media/exceptions/exceptions-vs-errors.png "Developers Developers Developers")
//: #### Error handling does exsist in both languages, here is an example:
/*:

    NSError *anyError;
    BOOL success = [receivedData writeToURL:someLocalFileURL
                                    options:0
                                      error:&anyError];

    if (!success) {
        NSLog(@"Write failed with error: %@", anyError);
        // present error to user
    }

*/

/*:

(BOOL)removeItemAtURL:(NSURL *)URL error:(NSError **)error;

// In Swift, converts to:

func removeItemAtURL(URL: NSURL) throws

// More info -> https://developer.apple.com/library/ios/documentation/Swift/Conceptual/BuildingCocoaApps/AdoptingCocoaDesignPatterns.html

*/

// Catch clauses

let fileManager = NSFileManager.defaultManager()
let fromURL = NSURL(fileURLWithPath: "/path/to/old")
let toURL = NSURL(fileURLWithPath: "/path/to/new")
do {
    try fileManager.moveItemAtURL(fromURL, toURL: toURL)
} catch let error as NSError {
    print("Error: \(error.localizedDescription)")
}

/*:
[Swift Error Handling Rationale]: https://github.com/apple/swift/blob/master/docs/ErrorHandlingRationale.rst "Swift error handling rationale"

For an exhaustive explanation of why Swift error handling is the way it is, go to [Swift Error Handling Rationale]
*/

//: ## Sidenote - playgrounds are cool

let swiftTemplate = [#Image(imageLiteral: "food_Unselected.png")#].imageWithRenderingMode(.AlwaysTemplate)

let imageView = UIImageView(image: swiftTemplate)
imageView.tintColor = [#Color(colorLiteralRed: 1, green: 1, blue: 1, alpha: 1)#]

let gradientLayer = CAGradientLayer()
gradientLayer.colors = [[#Color(colorLiteralRed: 0.146135608794414, green: 0.2406233813473808, blue: 0.9725490196, alpha: 1)#].CGColor, [#Color(colorLiteralRed: 0.1592609210791327, green: 1, blue: 0.9637462859556098, alpha: 1)#].CGColor]

let backgroundView = UIView(frame: imageView.bounds)
gradientLayer.frame = backgroundView.bounds

backgroundView.layer.addSublayer(gradientLayer)
backgroundView.addSubview(imageView)


for count in 0...1000 {
    cos(Double(count) / (2 * M_PI))
    
}
var myView = UIView(frame: CGRect(x: 0, y: 0, width: 200, height: 200))
myView.backgroundColor = UIColor.redColor()
myView.addSubview(backgroundView)

import XCPlayground

XCPlaygroundPage.currentPage.liveView = myView

UIView.animateWithDuration(2.0) { () -> Void in
    backgroundView.alpha = 0
    backgroundView.center = CGPoint(x: 200, y: 200)
}

